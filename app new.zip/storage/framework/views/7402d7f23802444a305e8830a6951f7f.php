

<?php $__env->startSection('content'); ?>
<h1 class="text-centre">Data Mahasiswa</h1>
<div class="row">

    
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
    <div class="mb-3">
        <a href="/tambahmahasiswa">
            <button type="button" class="btn btn-success">Tambah</button>
        </a>
    </div>
    <?php endif; ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success mt-2" role="alert">
            <?php echo e($message); ?>

        </div>
    <?php endif; ?>

    <table class="table mt-3">
        <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">Nama</th>
                <th scope="col">NIM</th>
                <th scope="col">Prodi</th>
                <th scope="col">Email</th>
                <th scope="col">No HP</th>
                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?> 
                    <th scope="col">Aksi</th> 
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php $i = 1 ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mahasiswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($i++); ?></th>
                <td><?php echo e($mahasiswa["name"]); ?></td>
                <td><?php echo e($mahasiswa["nim"]); ?></td>
                <td><?php echo e($mahasiswa["prodi"]); ?></td>
                <td><?php echo e($mahasiswa["email"]); ?></td>
                <td><?php echo e($mahasiswa["nohp"]); ?></td>
                
                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
                <td>
                    <a href="tampildata/<?php echo e($mahasiswa['id']); ?>" class="btn btn-primary">Edit</a>
                    
                    <a href="#" 
                       class="btn btn-danger delete" 
                       data-id="<?php echo e($mahasiswa['id']); ?>" 
                       data-nama="<?php echo e($mahasiswa['name']); ?>">
                       Hapus
                    </a>
                </td>
                <?php endif; ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>


<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    $('.delete').click(function(e) {
        e.preventDefault();
        let id = $(this).attr('data-id');
        let nama = $(this).attr('data-nama');

        Swal.fire({
            title: "Yakin ingin menghapus?",
            text: "Data mahasiswa " + nama + " akan dihapus permanen.",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Ya, Hapus!"
        }).then((result) => {
            if (result.isConfirmed) {
                window.location = "/deletedata/" + id;
            }
        });
    });

    <?php if(Session::has('success')): ?>
        Swal.fire({
            title: "Berhasil!",
            text: "<?php echo e(Session::get('success')); ?>",
            icon: "success"
        });
    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\rezanora\Adebare\resources\views/Mahasiswa.blade.php ENDPATH**/ ?>
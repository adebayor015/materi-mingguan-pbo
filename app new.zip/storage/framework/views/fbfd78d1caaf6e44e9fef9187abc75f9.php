

<?php $__env->startSection('content'); ?>
<div class="jumbotron bg-white shadow-sm border-0 py-5 px-4 rounded-lg text-center">
    <h1 class="display-4 font-weight-bold">Hello, Welcome!</h1>
    <p class="lead text-muted">Selamat datang di portal informasi DebayorTI.</p>
    <hr class="my-4">
    
    <?php if(auth()->guard()->check()): ?>
        <div class="alert alert-success d-inline-block px-5 shadow-sm border-0" style="border-radius: 50px;">
            🎉 Selamat Datang Kembali, <strong><?php echo e(auth()->user()->name); ?></strong>!
        </div>
    <?php else: ?>
        <p>Silakan login untuk mendapatkan akses penuh ke berita kami.</p>
        <a class="btn btn-primary btn-lg px-5 shadow" href="/login" role="button">Mulai Sekarang</a>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\rezanora\Adebare\resources\views/home.blade.php ENDPATH**/ ?>